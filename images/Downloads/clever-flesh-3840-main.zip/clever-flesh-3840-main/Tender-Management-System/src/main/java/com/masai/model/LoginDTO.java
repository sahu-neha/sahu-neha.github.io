package com.masai.model;

import lombok.Data;

@Data
public class LoginDTO {
	public String username;
	public String password;
}
