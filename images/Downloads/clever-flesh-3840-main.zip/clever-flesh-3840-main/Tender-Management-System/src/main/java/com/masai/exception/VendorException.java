package com.masai.exception;

public class VendorException extends Exception {
	public VendorException() {
	}

	public VendorException(String message) {
		super(message);
	}
}