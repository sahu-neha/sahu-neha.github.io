package com.masai.enums;

public enum BidStatus {
	APPROVED, REJECTED, PENDING;
}
