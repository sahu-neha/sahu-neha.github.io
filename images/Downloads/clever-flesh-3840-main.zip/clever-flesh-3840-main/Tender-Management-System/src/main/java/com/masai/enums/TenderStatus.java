package com.masai.enums;

public enum TenderStatus {
	AVAILABLE, BOOKED;
}
