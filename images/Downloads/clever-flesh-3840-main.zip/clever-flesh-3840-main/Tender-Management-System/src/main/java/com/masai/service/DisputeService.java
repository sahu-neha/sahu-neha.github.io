//package com.masai.service;
//
//import com.masai.exception.DisputeException;
//import com.masai.model.Dispute;
//
//public interface DisputeService {
//
//	// ========== A D D - N E W - D I S P U T E ========== //
//
//	public Dispute createDispute(Dispute dispute) throws DisputeException;
//	
//	// ========== G E T - D I S P U T E ========== //
//	
//
//}
