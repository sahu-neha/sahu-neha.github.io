package com.masai.enums;

public enum MessageBy {
	VENDOR, ADMIN;
}
