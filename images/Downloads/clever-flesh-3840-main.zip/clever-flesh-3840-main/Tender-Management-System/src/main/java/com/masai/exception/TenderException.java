package com.masai.exception;

public class TenderException extends Exception {
	public TenderException() {
	}

	public TenderException(String message) {
		super(message);
	}
}