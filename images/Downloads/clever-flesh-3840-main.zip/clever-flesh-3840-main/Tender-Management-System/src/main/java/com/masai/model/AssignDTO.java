package com.masai.model;

import lombok.Data;

@Data
public class AssignDTO {
	private Integer tenderId;
	private Integer venderId;
}
