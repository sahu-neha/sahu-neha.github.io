package com.masai.exception;

public class DisputeException extends Exception {
	public DisputeException() {
	}

	public DisputeException(String message) {
		super(message);
	}
}